Midnight Delivery Question 2
Source commit ad07a923fedf16cd11f840f2dd24eed4a43c1635

This is the base free-driving version.
Extract the archive, then open PowerShell in this folder.
Python 3.12 and an OpenGL 3.3 Core graphics driver are required.

py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe main.py

Dependencies install from the internet; gameplay is offline.
See the Question 2 report for controls and the marker walkthrough.
The original repository README is preserved, while these packaging instructions refer to the submitted version.
ChatGPT assisted with code and documentation.
