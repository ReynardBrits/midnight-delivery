# Midnight Delivery — Question 2

**Student:** Reynard Brits  
**Project:** ITGDA Project 2  
**Built with:** Python, PyGame and PyOpenGL

This is the base implementation of Midnight Delivery. It is a top-down driving game set in a fictional South African coastal town. At this stage, the player can explore the environment, drive the courier car, test collisions and listen to the background ambience.

The completed delivery campaign belongs to Question 3. This Q2 version does not include delivery jobs, traffic, scoring, fuel or shift progression.

## What is included

- A 2560 × 1920 town with connected roads and intersections.
- Buildings, pavements, a depot, a park and a waterfront.
- A courier car with acceleration, steering, braking and reversing.
- Collisions with buildings, obstacles and the map boundary.
- A camera that follows the car and stops at the map edges.
- Brake lights and reverse lights.
- Background wind and cricket sounds, with a mute control.
- Automatic pausing when the game window loses focus.

The game uses a 1280 × 720 window. Movement updates at 120 Hz, with interpolation between updates to make movement appear smoother. The target rendering frame rate is 60 FPS; actual performance depends on the computer.

## Requirements

- Windows with Python 3.12. The development version was Python 3.12.10.
- PyGame 2.6.1 and PyOpenGL 3.1.10.
- A graphics driver supporting OpenGL 3.3 Core.
- A keyboard and a display that can show a 1280 × 720 window.
- Speakers or headphones for sound.

Internet access is needed to install the Python packages. The game runs offline afterwards.

## Installation and running

1. Extract the whole ZIP file.
2. Open the `MidnightDelivery_Question2` folder.
3. Open PowerShell in that folder. It should contain `main.py` and `requirements.txt`.
4. Run these commands:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe main.py
```

After the first setup, start the game with:

```powershell
.\.venv\Scripts\python.exe main.py
```

You do not need to activate the virtual environment because these commands use its Python directly. Click the game window if the keyboard controls are not responding.

## Controls

| Key | Action |
| --- | --- |
| W or Up | Accelerate forward |
| S or Down | Brake, then reverse |
| A / D or Left / Right | Steer |
| Space | Strong brake |
| R | Reset the car to its starting position |
| M | Mute or unmute the ambience |
| Escape | Exit the game |

The car needs to be moving before steering takes effect. When changing direction, it slows down before moving the other way. The title bar displays speed in pixels per second in this base version.

Switching to another window pauses movement and ambience. They resume when the game receives focus again.

## What to try

1. Drive along the roads and turn at a junction.
2. Find the depot and its loading bay in the north-west.
3. Visit the park and the waterfront.
4. Test braking and reversing, and check the vehicle lights.
5. Drive gently towards a building to check that the car cannot pass through it.
6. Press R to reset the car and M to check the sound control.

This stage is free driving. There is no delivery objective or ending yet.

## Files

| File | Purpose |
| --- | --- |
| `main.py` | Window setup, input and game loop |
| `world.py` | Town layout, scenery and obstacles |
| `car.py` | Car appearance, movement, collisions and lights |
| `camera.py` | Camera movement and screen positions |
| `renderer.py` | OpenGL drawing and shaders |
| `audio.py` | Background ambience and sound controls |
| `requirements.txt` | Required Python packages and versions |
| `SOURCE_VERSION.txt` | Original Q2 source version details |

## Visuals and sound

The environment and vehicle are built from coloured shapes in code. The background ambience is generated in `audio.py` and played through PyGame. This version does not need downloaded image packs, music or sound recordings. The interface uses PyGame's bundled default font.

## Troubleshooting

**Python 3.12 is not found:** Run `py --list` to check which versions are installed. Install Python 3.12 if it is missing.

**A module is missing:** Run the dependency installation command again, then launch the game using `.\.venv\Scripts\python.exe main.py`.

**An OpenGL error appears:** Check that the graphics hardware and driver support OpenGL 3.3 Core. Update the graphics driver if needed.

**There is no sound:** Check the computer's volume and output device, then press M. The title bar shows whether sound is muted or unavailable. The game can continue without sound if audio initialisation fails.

## References

- Python virtual environments: https://docs.python.org/3.12/tutorial/venv.html
- PyGame display: https://www.pygame.org/docs/ref/display.html
- PyGame keyboard input: https://www.pygame.org/docs/ref/key.html
- PyGame timing: https://www.pygame.org/docs/ref/time.html
- PyGame sound: https://www.pygame.org/docs/ref/mixer.html
- PyOpenGL: https://pyopengl.sourceforge.net/
- Game loop concepts: https://gameprogrammingpatterns.com/game-loop.html
